## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(cache = TRUE, fig.align = "center", fig.width = 5, fig.height = 5,
                      cache.path = "./cache_knitr/Exo_pred/", fig.path = "./fig_knitr/Exo_pred/")

