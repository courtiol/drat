.build_vignettes <- function() {
  #devtools::build_vignettes(pkg = ".", dependencies = "VignetteBuilder", clean = FALSE,
  #                          upgrade = "never", quiet = FALSE, install = TRUE,
  #                          keep_md = TRUE)
  pkg <- devtools::as.package(".")
  remotes::dev_package_deps(pkg$path, dependencies = "VignetteBuilder")
  message("Building ", pkg$package, " vignettes")
  tools::buildVignettes(dir = pkg$path, tangle = TRUE, clean = FALSE)
  devtools:::copy_vignettes(pkg, keep_md = FALSE)
  invisible(TRUE)
}

.update_drat <- function() {
  path <- devtools::build(binary = FALSE, vignettes = TRUE)
  drat::insertPackage(path, "~/Boulot/Mes_projets_de_recherche/R_packages/drat", commit = TRUE)
  system("cd ~/Boulot/Mes_projets_de_recherche/R_packages/drat; git push") ## note: takes a while
}
